package cn.snowing.msg;

public interface ReturnMsg {
    public ReturnMsg getReturnMsg();
}
